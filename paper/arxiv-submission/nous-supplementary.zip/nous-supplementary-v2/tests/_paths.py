"""Shared path constants for Nous tests."""
import os
from pathlib import Path


def _detect_clawd_root() -> Path:
    """Detect clawd workspace root. Checks CLAWD_ROOT env, then parent heuristic."""
    env = os.environ.get("CLAWD_ROOT")
    if env:
        return Path(env).resolve()
    # nous/ is typically inside clawd/
    candidate = Path(__file__).parent.parent.parent
    if (candidate / "memory" / "entities").exists():
        return candidate
    return Path.home() / "clawd"  # fallback


CLAWD_ROOT = _detect_clawd_root()
ENTITIES_ROOT = CLAWD_ROOT / "memory" / "entities"

# True only when the personal KG seed directory is present (host-specific).
# Tests that need real KG entities use this to skip cleanly on bare CI runners
# and on machines where the entities dir was anonymised away for public release.
KG_AVAILABLE = ENTITIES_ROOT.exists()
