# Nous — Compositional Runtime Safety Gate (anonymized supplementary, NeurIPS 2026 E&D)

Anonymized code drop for the paper "Owner-Harm: A Missing Threat Model for AI Agent Safety".
Apache License 2.0; full public repo available upon acceptance.

## Setup

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[lsvj,dev]"
```

## Reproduce

```bash
# Deterministic (no API key)
pytest tests/lsvj/                          # ~10s
python scripts/full_benchmark_eval.py       # ~30s
python scripts/eval_d2_verifier.py          # ~10s
cd benchmarks/agentdojo_adapter && uv run --project . python run_eval.py    # ~1-3 min

# LLM-bound
export OPENAI_API_KEY=$DEEPSEEK_API_KEY NOUS_BASE_URL=https://api.deepseek.com/v1 NOUS_SEMANTIC_MODEL=deepseek-chat
python scripts/run_agentharm_threelayer_v2.py   # ~36 min, ~$3
```

See REPRODUCIBILITY.md for the full claim-to-command mapping.
