# Nous — Compositional Runtime Safety Gate (NeurIPS 2026 E&D anonymized supplementary)

This is the anonymized supplementary code drop for the paper
"Owner-Harm: A Missing Threat Model for AI Agent Safety". The full
public repository will be released under Apache License 2.0 upon
acceptance.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[lsvj,dev]"
pip install -e ".[cozo]"   # optional: KG-bound paths
```

## Reproduce the paper

See `REPRODUCIBILITY.md` for a per-claim reproduction matrix. The
deterministic claims (LSVJ-S compile gate, Owner-Harm v3 full L1-L4,
Hijacking layer overlap) require no API key and complete in under one
minute on commodity hardware. The LLM-bound claims (AgentDojo
deployment, AgentHarm L1+L2+L3) require the corresponding subscription
endpoint.

## License

Apache License 2.0. See LICENSE.
